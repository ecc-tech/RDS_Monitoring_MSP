import json
import requests
import os
import re
from datetime import datetime
import urllib3

urllib3.disable_warnings()

# Load configuration
OSTICKET_API_KEY = os.environ['OSTICKET_API_KEY']
OSTICKET_API_URL = os.environ['OSTICKET_API_URL']
ACCOUNT_ID_NAME_MAP = json.loads(os.environ.get('ACCOUNT_ID_NAME_MAP', '{}'))

def format_time(timestamp):
    try:
        parsed = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S.%f%z")
        return parsed.strftime("%d/%m/%Y %H:%M:%S %Z")
    except Exception:
        return timestamp or "Unavailable"

def extract_db_instance_id(trigger):
    for dim in trigger.get('Dimensions', []):
        if dim.get('name') == 'DBInstanceIdentifier':
            return dim.get('value', 'Unknown-DB')
    return "Unknown-DB"

def extract_usage(reason, metric):
    try:
        datapoints = re.findall(r'\[(.*?)\]', reason)
        if datapoints:
            usage_value = float(datapoints[0].split()[0])
            threshold_match = re.search(r'threshold\s+\(([\d.Ee+-]+)\)', reason)
            threshold_val = float(threshold_match.group(1)) if threshold_match else None

            if 'freestoragespace' in metric or 'freeablememory' in metric:
                usage_gb = usage_value / (1024 ** 3)
                threshold_gb = threshold_val / (1024 ** 3) if threshold_val else None
                if threshold_gb:
                    simplified = f"Threshold Crossed: [{usage_gb:.2f} GB free {'<' if usage_gb < threshold_gb else '>'} threshold ({threshold_gb:.2f} GB)]"
                else:
                    simplified = f"Threshold Crossed: [{usage_gb:.2f} GB free]"
                return f"{usage_gb:.2f} GB", simplified
            else:
                simplified = f"Threshold Crossed: [{usage_value:.2f} {'<' if usage_value < threshold_val else '>'} threshold ({threshold_val})]" if threshold_val else f"Threshold Crossed: [{usage_value:.2f}]"
                return f"{usage_value:.2f}", simplified
    except Exception as e:
        print("❌ Regex error:", str(e))

    return "N/A", reason

def get_account_name(account_id):
    return ACCOUNT_ID_NAME_MAP.get(account_id, f"Account-{account_id}")

def send_ticket(subject, message_body):
    ticket_data = {
        'name': 'RDS Resource Alert',
        'email': 'csborle@gmail.com',
        'subject': subject,
        'message': message_body,
        'priority': '3'
    }

    headers = {
        'X-API-Key': OSTICKET_API_KEY,
        'Content-Type': 'application/json'
    }

    try:
        response = requests.post(
            f"{OSTICKET_API_URL}/tickets.json",
            headers=headers,
            json=ticket_data,
            verify=False
        )

        print(f"Ticket API status: {response.status_code}")
        print(f"Response: {response.text}")

        if response.status_code != 201:
            raise Exception(f"Ticket creation failed: {response.text}")
        return response.text.strip()
    except Exception as e:
        print("❌ Ticket sending error:", str(e))
        raise

def lambda_handler(event, context):
    print("Received event:", json.dumps(event, indent=4))

    try:
        alerts = []
        record = event['Records'][0]
        sns = record['Sns']
        account_id = sns['MessageAttributes'].get('AWSAccountId', {}).get('Value')

        if not account_id:
            message_data = json.loads(sns['Message'])
            account_id = message_data.get("AWSAccountId", "Unknown")

        account_name = get_account_name(account_id)

        for record in event['Records']:
            message = json.loads(record['Sns']['Message'])

            alarm_name = message.get('AlarmName', 'Unknown Alarm')
            reason = message.get('NewStateReason', 'No Reason')
            region = message.get('Region', 'Unknown Region')
            timestamp = format_time(message.get('StateChangeTime'))
            db_instance = extract_db_instance_id(message.get('Trigger', {}))
            metric_name = message.get('Trigger', {}).get('MetricName', '').lower()

            usage_value, cleaned_reason = extract_usage(reason, metric_name)

            # Determine alert type
            if 'cpu' in metric_name:
                alert_title = "⚠️ RDS CPU Utilization Alert"
                alert_type = "CPU Usage"
            elif 'freeablememory' in metric_name:
                alert_title = "⚠️ RDS Memory Alert"
                alert_type = "Freeable Memory"
            elif 'freestoragespace' in metric_name:
                alert_title = "⚠️ RDS Storage Alert"
                alert_type = "Free Storage"
            elif 'databaseconnections' in metric_name:
                alert_title = "⚠️ RDS DB Connection Alert"
                alert_type = "Database Connections"
            else:
                alert_title = "⚠️ RDS Unknown Metric Alert"
                alert_type = "Reason"

            body = (
                f"{alert_title}\n"
                f"- Alarm: {alarm_name}\n"
                f"- Region: {region}\n"
                f"- Time: {timestamp}\n"
                f"- DB Instance: {db_instance}\n"
                f"- {alert_type}: {cleaned_reason}"
            )

            alerts.append(body)

        if alerts:
            full_message = "\n\n" + ("\n\n" + "-" * 60 + "\n\n").join(alerts)
            subject = f"⚠️ RDS Alert - (Ac Name: {account_name} | Ac No: {account_id})"

            ticket_response = send_ticket(subject, full_message)
            print(f"✅ Ticket created. Response: {ticket_response}")
        else:
            print("ℹ️ No RDS alerts to process.")

    except Exception as e:
        print("❌ General error in processing RDS alarms:", str(e))
