import json
import requests
import os
from datetime import datetime
import urllib3

urllib3.disable_warnings()

# Load configuration
OSTICKET_API_KEY = os.environ['OSTICKET_API_KEY']
OSTICKET_API_URL = os.environ['OSTICKET_API_URL']
ACCOUNT_ID_NAME_MAP = json.loads(os.environ.get('ACCOUNT_ID_NAME_MAP', '{}'))

def format_time(iso_timestamp):
    try:
        parsed = datetime.strptime(iso_timestamp, "%Y-%m-%dT%H:%M:%S.%fZ")
        return parsed.strftime("%d/%m/%Y %H:%M:%S UTC")
    except Exception:
        return iso_timestamp or "Unknown"

def get_account_name(account_id):
    return ACCOUNT_ID_NAME_MAP.get(account_id, f"Account-{account_id}")

def send_ticket(subject, message_body):
    ticket_data = {
        'name': 'AWS CloudWatch RDS State Event',
        'email': 'csborle@gmail.com',
        'subject': subject,
        'message': message_body,
        'priority': '3'
    }

    headers = {
        'X-API-Key': OSTICKET_API_KEY,
        'Content-Type': 'application/json'
    }

    try:
        response = requests.post(
            f"{OSTICKET_API_URL}/tickets.json",
            headers=headers,
            json=ticket_data,
            verify=False
        )

        print(f"Ticket API status: {response.status_code}")
        print(f"Response: {response.text}")

        if response.status_code != 201:
            raise Exception(f"Ticket creation failed: {response.text}")
        return response.text.strip()
    except Exception as e:
        print("❌ Ticket sending error:", str(e))
        raise

def lambda_handler(event, context):
    print("Received event:", json.dumps(event, indent=4))

    try:
        for record in event['Records']:
            sns_message = json.loads(record['Sns']['Message'])

            account_id = sns_message.get("account", "Unknown")
            region = sns_message.get("region", "Unknown")
            detail = sns_message.get("detail", {})

            db_instance = detail.get("SourceIdentifier", "Unknown DB")
            event_message = detail.get("Message", "No message provided")
            event_time = format_time(detail.get("Date", ""))

            account_name = get_account_name(account_id)

            subject = f"🔁 RDS Event: {event_message} - {db_instance} (Ac Name: {account_name} | Ac No: {account_id})"
            body = (
                f"🔁 RDS State Change Notification\n\n"
                f"- Time: {event_time}\n"
                f"- Region: {region}\n"
                f"- DB Instance: {db_instance}\n"
                f"- Event Message: {event_message}"
            )

            ticket_response = send_ticket(subject, body)
            print(f"✅ Ticket created. Response: {ticket_response}")

    except Exception as e:
        print("❌ General error in processing RDS instance state event:", str(e))
